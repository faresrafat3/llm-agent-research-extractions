# أرسينال — مخطط خط الأنابيب الموحّد الرئيسي (عربي)

**نظام واحد. عشرة مصادر. طبقات متداخلة L0–L6.**

- **L1** = APE أساس + OPRO تكراري (+ تسلسل)
- **L3** = ToT أساس + LATS كامل (+ تسلسل)
- **L5** = ذاكرة Reflexion اللفظية + مهارات/منهج Voyager اختياري

انظر: `search_family_map.md`

## Mermaid

```mermaid
flowchart TB
  %% أرسينال — خط الأنابيب الموحّد الرئيسي من دمج الأنظمة العشرة
  %% المصادر: AI Scientist v2 | Self-Refine | Reflexion | Meta-Prompting | ToT | LATS | APE | Prompt Report
  %% المصادر: AI Scientist v2 | Self-Refine | Reflexion | Meta-Prompting | LATS | APE | The Prompt Report

  START([مهمة المستخدم / فكرة بحثية / استعلام]) --> L6_IN[L6 غلاف المراحل التصاعدي<br/>AI Scientist v2]

  %% ═══════════════ L6 المراحل الخارجية ═══════════════
  subgraph L6["L6 — غلاف المراحل التصاعدي (AI Scientist v2)"]
    direction TB
    L6_IN --> STAGE{المرحلة الحالية}
    STAGE -->|1 مسودة| S1[المرحلة 1: التنفيذ الأولي / المسودة]
    STAGE -->|2 ضبط| S2[المرحلة 2: خط الأساس + ضبط المعاملات]
    STAGE -->|3 تحسين| S3[المرحلة 3: تحسينات بحثية إبداعية]
    STAGE -->|4 عزل| S4[المرحلة 4: دراسات العزل Ablation]
    S1 --> TRIAL_WRAP
    S2 --> TRIAL_WRAP
    S3 --> TRIAL_WRAP
    S4 --> TRIAL_WRAP

    TRIAL_WRAP[الدخول إلى حلقة محاولات L5 مع ذاكرة المرحلة]

    TRIAL_DONE[عودة أفضل نتيجة من المكدس] --> BEST{هل وُجدت أفضل عقدة / نتيجة؟}
    BEST -->|لا| ABORT[إيقاف المسار — تسجيل no_best_node]
    BEST -->|نعم| MSEED[تقييم متعدد البذور Multi-seed]
    MSEED --> PLOTS[توليد الرسوم + تغذية VLM + التجميع]
    PLOTS --> STAGE_OK{اكتملت المرحلة / مراحل أخرى؟}
    STAGE_OK -->|نعم التالية| STAGE
    STAGE_OK -->|اكتملت الكل| WRITEUP_GATE{هل الكتابة مفعّلة؟}
  end

  %% ═══════════════ L5 المحاولات والذاكرة ═══════════════
  subgraph L5["L5 — الذاكرة (Reflexion لفظي + Voyager مهارات)"]
    direction TB
    TRIAL_WRAP --> MEM_INIT[memory = آخر K تأملات؛ skill_bank اختياري]
    MEM_INIT --> TRIAL_LOOP{لكل محاولة trial حتى max_trials}
    TRIAL_LOOP --> L0_CALL[استدعاء موجّه التقنيات L0]
    INNER_DONE[نتيجة المكدس الداخلي] --> SUCC{نجاح؟}
    SUCC -->|نعم| VYG{voyager مفعّل؟}
    VYG -->|نعم| VSKILL[اختياري: add_skill + مهمة المنهج التالية]
    VYG -->|لا| TRIAL_DONE
    VSKILL --> TRIAL_DONE
    SUCC -->|لا ومحاولات منتهية| TRIAL_DONE
    SUCC -->|لا وتبقى محاولات| REFLECT[تأمل لفظي P5 من المسار + التغذية الراجعة]
    REFLECT --> MEM_UPD[إلحاق التأمل — الإبقاء على آخر K]
    MEM_UPD --> TRIAL_LOOP
  end

  %% ═══════════════ L0 الموجّه ═══════════════
  subgraph L0["L0 — موجّه التقنيات (The Prompt Report)"]
    direction TB
    L0_CALL --> TAX[التصنيف وفق تصنيف 58 تقنية<br/>+ وكلاء / متعدد الوسائط / تقييم]
    TAX --> FAM{عائلات التقنيات}
    FAM --> F1[تعلّم في السياق ICL]
    FAM --> F2[توليد التفكير عائلة CoT]
    FAM --> F3[التفكيك ToT/PoT/L2M]
    FAM --> F4[التجميع Self-Consistency]
    FAM --> F5[النقد الذاتي Refine/Reflexion]
    FAM --> F6[تحسين الأوامر APE/OPRO]
    FAM --> F7[وكلاء وأدوات ReAct]
    F1 & F2 & F3 & F4 & F5 & F6 & F7 --> ACT[بناء أعلام التفعيل]
    ACT --> FLAGS["تفعيل: ape / opro / meta / tot / lats / refine / reflexion / voyager / stages"]
    FLAGS --> L1_GATE
  end

  %% ═══════════════ L1 APE ═══════════════
  subgraph L1["L1 — محسّن التعليمات (APE + OPRO)"]
    direction TB
    L1_GATE{وضع L1؟}
    L1_GATE -->|off| L1_SKIP[أوامر افتراضية / يدوية]
    L1_GATE -->|ape| APE_PATH[APE: توليد → إزالة تكرار → likelihood/UCB → ترتيب]
    L1_GATE -->|opro| OPRO_PATH[OPRO: درجات البذور → meta_prompt → تطور → إعادة تقييم]
    L1_GATE -->|cascade| APE_THEN[APE تهيئة البذور]
    APE_THEN --> OPRO_PATH
    APE_PATH --> APE_OUT[أفضل الأوامر + demo_fn]
    OPRO_PATH --> APE_OUT
    APE_OUT --> L2_GATE
    L1_SKIP --> L2_GATE
  end

  %% ═══════════════ L2 META ═══════════════
  subgraph L2["L2 — المايسترو الميتا (Meta-Prompting)"]
    direction TB
    L2_GATE{activate.meta؟}
    L2_GATE -->|لا| L2_SKIP{activate.tot أو activate.lats؟}
    L2_GATE -->|نعم| META_INIT[تهيئة الرسائل: تعليمات ميتا + الاستعلام + الذاكرة]
    META_INIT --> META_LOOP{جولة ميتا < الحد الأقصى}
    META_LOOP --> META_CALL[توليد نموذج الميتا]
    META_CALL --> META_KIND{نوع المخرج؟}
    META_KIND -->|إجابة نهائية| META_FINAL[استخراج FINAL ANSWER]
    META_KIND -->|غير صالح| META_ERR[إلحاق تغذية راجعة لخطأ التنسيق]
    META_ERR --> META_LOOP
    META_KIND -->|استدعاء خبير| META_EXP[استخراج اسم الخبير + التعليمات]
    META_EXP --> EXP_TYPE{نوع الخبير؟}
    EXP_TYPE -->|بايثون| EXP_PY[توليد خبير بايثون]
    EXP_PY --> RUN_Q{Please run this code؟}
    RUN_Q -->|نعم| EXEC[تنفيذ بمهلة زمنية — إلحاق stdout/err]
    RUN_Q -->|لا| EXP_APPEND
    EXEC --> EXP_APPEND
    EXP_TYPE -->|بحث شجري| L3_MODE
    EXP_TYPE -->|خبير عادي| EXP_LM[توليد خبير لغوي]
    EXP_LM --> L4_EXP[صقل مسودة الخبير عبر L4]
    L4_EXP --> EXP_APPEND[إلحاق مخرج الخبير + تغذية راجعة وسيطة]
    EXP_APPEND --> META_LOOP
    META_FINAL --> L4_FINAL
    L2_SKIP -->|نعم| L3_MODE
    L2_SKIP -->|لا| DIRECT[توليد مباشر بالطريقة الموجَّهة]
    DIRECT --> L4_FINAL
  end

  %% ═══════════════ L3 LATS ═══════════════
  subgraph L3["L3 — محرك البحث الشجري (ToT أساس + LATS كامل)"]
    direction TB
    L3_MODE{وضع البحث؟}
    L3_MODE -->|ToT دون اتصال/لغز| TOT[ToT: حدود ys فارغة]
    L3_MODE -->|LATS تفاعلي/بيئة| L3_CALL
    L3_MODE -->|تسلسل cascade| TOT
    TOT --> TOT_STEP{لكل step في task.steps}
    TOT_STEP --> TOT_GEN{توليد sample أو propose؟}
    TOT_GEN --> TOT_EVAL{تقييم value أو vote؟}
    TOT_EVAL --> TOT_SEL[اختيار أفضل b greedy أو sample]
    TOT_SEL --> TOT_STEP
    TOT_STEP -->|انتهى| TOT_OUT[أفضل مسارات ToT]
    TOT_OUT --> CASC{cascade والدرجة < tau؟}
    CASC -->|نعم ترقية| L3_CALL
    CASC -->|لا| L4_LEAF
    L3_CALL[العقدة الجذر = الحالة / السؤال / المسألة] --> MCTS{لكل تكرار 1..N}
    MCTS --> SEL[اختيار عقدة بـ UCT]
    SEL --> TERM{حالة العقدة؟}
    TERM -->|نجاح طرفي| L3_WIN[إرجاع مسار ناجح]
    TERM -->|فشل طرفي / مستنفد| BACKTRACK[تقليم / تراجع]
    BACKTRACK --> MCTS
    TERM -->|قابل للتوسعة| EXPAND[توسيع: عينات LM أفكار/أفعال/كود بعرض W]
    EXPAND --> VALUE[تقييم الأبناء: قيمة LM + تغذية البيئة]
    VALUE --> ROLLOUT[محاكاة أفضل ابن حتى العمق الأقصى]
    ROLLOUT --> ROK{نجاح أثناء المحاكاة؟}
    ROK -->|نعم| L3_WIN
    ROK -->|لا| BPROP[إعادة نشر المكافأة/القيمة للجذر]
    BPROP --> FAIL_STORE[تخزين المسار الفاشل]
    FAIL_STORE --> REFL_Q{هل تستحق الإخفاقات الفريدة تأملاً؟}
    REFL_Q -->|نعم| L3_REFL[أمر تأمل ذاتي → قائمة التأملات]
    REFL_Q -->|لا| MCTS
    L3_REFL --> MCTS
    L3_WIN --> L4_LEAF
    MCTS -->|استنفاد الميزانية| L3_BEST[أفضل مسار جزئي]
    L3_BEST --> L4_LEAF
  end

  %% ═══════════════ L4 SELF-REFINE ═══════════════
  subgraph L4["L4 — الصاقل المحلي (Self-Refine)"]
    direction TB
    L4_LEAF[ورقة مرشحة / مسودة y] --> L4_INIT{هل y موجودة؟}
    L4_FINAL[مرشح للصقل النهائي] --> L4_INIT
    L4_INIT -->|لا| L4_GEN[y0 = M p_gen || x]
    L4_INIT -->|نعم| L4_Y[استخدام المرشح كـ y_t]
    L4_GEN --> L4_LOOP
    L4_Y --> L4_LOOP{لكل t حتى max_iters}
    L4_LOOP --> L4_FB[fb_t = M p_fb || x || y_t<br/>درجات متعددة الجوانب]
    L4_FB --> L4_STOP{إيقاف fb_t t ؟}
    L4_STOP -->|نعم عبارة إيقاف أو الحد| L4_OUT[إرجاع y_final + السجل]
    L4_STOP -->|لا| L4_REF[y_t+1 = M p_refine || x || السجل الكامل]
    L4_REF --> L4_HIST[إلحاق y_t fb_t بالسجل]
    L4_HIST --> L4_LOOP
  end

  L4_OUT --> INNER_DONE

  %% ═══════════════ ذيل الإنتاج L6 ═══════════════
  WRITEUP_GATE -->|لا| DELIVER([تسليم مخرجات المراحل + السجل])
  WRITEUP_GATE -->|نعم| CITE[حلقة الاستشهاد: Semantic Scholar ~20 جولة]
  CITE --> WRITE[كتابة الورقة LaTeX / التوليد]
  WRITE --> WREF{جولات تأمل الكتابة}
  WREF --> WREV[مراجعة الوضوح والأدلة وحدود الصفحات والأشكال]
  WREV --> WREF
  WREF -->|انتهى| PREVIEW{مراجعة الأقران مفعّلة؟}
  PREVIEW -->|نعم| PREVIEW_DO[مراجعة LLM + مراجعة VLM للأشكال + ميتا-مراجعة]
  PREVIEW -->|لا| DELIVER
  PREVIEW_DO --> DELIVER
  ABORT --> DELIVER

  subgraph LEGEND["مصادر الأنماط"]
    direction LR
    LG0[L0 توجيه تصنيف Prompt Report]
    LG1[L1 APE + OPRO تحسين التعليمات]
    LG2[L2 ميتا توزيع الخبراء + أداة بايثون]
    LG3[L3 ToT حزمة/DFS + LATS UCT/MCTS]
    LG4[L4 Self-Refine توليد-تغذية-صقل-إيقاف]
    LG5[L5 Reflexion لفظي + Voyager مهارات/منهج]
    LG6[L6 AI Scientist مراحل بذور متعددة كتابة مراجعة]
  end

  DELIVER --> END([مخرجات أرسينال:<br/>أوامر · مسارات · قطع أثرية · ورقة · مراجعة · ذاكرة])

```
